# NeuroAssist – Live Captions Dashboard

NeuroAssist turns speech into easy‑to‑read captions in the browser. It is designed for hearing‑impaired users and works on a laptop or desktop.

## Use it from GitHub (no terminal)

This repository includes a **static website** under the [`docs/`](docs/) folder. You can host it on **GitHub Pages** so anyone can open it in a browser—no install or server on their machine.

### Enable GitHub Pages

1. Push this repository to GitHub.
2. In the repo on GitHub, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**.
4. Choose your default branch (usually `main`) and folder **`/docs`**, then save.
5. After a short build, GitHub shows your site URL at the top of the Pages settings, for example  
   `https://<your-username>.github.io/<repository-name>/`

Open that URL, click **Open app**, then **Live Captions**. Grant microphone access when asked.

**Transcripts** are saved only in the visitor’s browser (**IndexedDB**). They are not uploaded to GitHub. Clearing site data or using another device starts with an empty history.

More detail: [docs/documentation/getting-started.html](docs/documentation/getting-started.html).

---

## Optional: run a local Python server

If you want a local server with **SQLite** (same schema as `prisma/migrations/`) instead of IndexedDB, you can run the Flask app from the repo root:

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Then open `http://localhost:5000` (Flask serves the Jinja templates in `templates/`, not the static `docs/` tree).

### JSON APIs (Flask only)

- `POST /api/transcripts`, `GET /api/transcripts/list`, `POST /api/contact`

The GitHub Pages build does not use these; captions and history use **IndexedDB** in the browser.

### Regenerating static HTML (maintainers only)

If you change [`docs/_build_static_pages.py`](docs/_build_static_pages.py), run:

```bash
python3 docs/_build_static_pages.py
```

That overwrites the generated `.html` files next to it under `docs/`.
