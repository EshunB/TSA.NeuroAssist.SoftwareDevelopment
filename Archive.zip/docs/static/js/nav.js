/**
 * Injects site header navigation. Each page sets:
 *   data-nav="marketing" | "app"
 *   data-nav-depth="0" (docs root) | "1" (app/ or documentation/)
 *   data-active="features.html" (filename to mark current)
 */
(function () {
  function prefix(depth) {
    return depth === "1" ? "../" : "";
  }

  function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/"/g, "&quot;");
  }

  function inject() {
    var body = document.body;
    var depth = body.getAttribute("data-nav-depth") || "0";
    var navType = body.getAttribute("data-nav") || "marketing";
    var active = body.getAttribute("data-active") || "";
    var p = prefix(depth);

    var marketingNav =
      '<a href="' +
      p +
      'features.html" class="nav-link' +
      (active === "features.html" ? " active" : "") +
      '">Features</a>' +
      '<a href="' +
      p +
      'pricing.html" class="nav-link' +
      (active === "pricing.html" ? " active" : "") +
      '">Pricing</a>' +
      '<a href="' +
      p +
      'about.html" class="nav-link' +
      (active === "about.html" ? " active" : "") +
      '">About</a>' +
      '<a href="' +
      p +
      'documentation/index.html" class="nav-link' +
      (active === "doc" ? " active" : "") +
      '">Docs</a>' +
      '<a href="' +
      p +
      'contact.html" class="nav-link' +
      (active === "contact.html" ? " active" : "") +
      '">Contact</a>';

    var appNav =
      '<a href="' +
      p +
      'app/captions.html" class="nav-link' +
      (active === "captions.html" ? " active" : "") +
      '">Captions</a>' +
      '<a href="' +
      p +
      'app/transcripts.html" class="nav-link' +
      (active === "transcripts.html" || active === "transcript.html" ? " active" : "") +
      '">History</a>' +
      '<a href="' +
      p +
      'app/settings.html" class="nav-link' +
      (active.indexOf("settings") === 0 ? " active" : "") +
      '">Settings</a>';

    var navInner = navType === "app" ? appNav : marketingNav;
    var aria = navType === "app" ? "App navigation" : "Site navigation";

    var actions =
      navType === "app"
        ? '<a class="btn btn-outline btn-sm" href="' +
          p +
          'documentation/index.html">Docs</a>'
        : '<a class="btn btn-primary btn-sm" href="' +
          p +
          'app/index.html">Open app</a>';

    var brandHref = p + "index.html";

    var html =
      '<header class="site-header">' +
      '<div class="site-header-inner">' +
      '<div class="nav-cluster">' +
      '<a href="' +
      brandHref +
      '" class="brand">NeuroAssist</a>' +
      '<nav class="site-nav" aria-label="' +
      esc(aria) +
      '">' +
      navInner +
      "</nav></div>" +
      '<div class="header-actions">' +
      actions +
      "</div></div></header>";

    var root = document.getElementById("nav-root");
    if (root) root.innerHTML = html;
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", inject);
  } else {
    inject();
  }
})();
