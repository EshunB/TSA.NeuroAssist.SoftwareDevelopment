(function () {
  function inject() {
    var body = document.body;
    if (body.getAttribute("data-show-footer") !== "true") return;
    var depth = body.getAttribute("data-nav-depth") || "0";
    var p = depth === "1" ? "../" : "";
    var y = new Date().getFullYear();
    var html =
      '<footer class="site-footer">' +
      '<div class="site-footer-inner">' +
      "<p>© " +
      y +
      " NeuroAssist. Built for accessibility first.</p>" +
      '<nav class="footer-nav" aria-label="Footer">' +
      '<a href="' +
      p +
      'accessibility.html">Accessibility</a>' +
      '<a href="' +
      p +
      'privacy.html">Privacy</a>' +
      '<a href="' +
      p +
      'security.html">Security</a>' +
      '<a href="' +
      p +
      'documentation/index.html">Docs</a>' +
      '<a href="' +
      p +
      'contact.html">Contact</a>' +
      "</nav></div></footer>";
    var root = document.getElementById("footer-root");
    if (root) root.innerHTML = html;
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", inject);
  } else {
    inject();
  }
})();
