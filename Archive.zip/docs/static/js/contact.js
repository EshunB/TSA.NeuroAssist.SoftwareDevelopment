(function () {
  document.addEventListener("DOMContentLoaded", function () {
    var form = document.getElementById("contact-form");
    var status = document.getElementById("contact-status");
    if (!form) return;

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var name = (form.elements.namedItem("fromName") || {}).value || "";
      var email = (form.elements.namedItem("email") || {}).value || "";
      var message = (form.elements.namedItem("message") || {}).value || "";
      var subject = encodeURIComponent("NeuroAssist contact: " + name);
      var body = encodeURIComponent(
        "Name: " + name + "\nEmail: " + email + "\n\n" + message
      );
      window.location.href = "mailto:?subject=" + subject + "&body=" + body;
      if (status) {
        status.textContent =
          "If your mail program opened, add the recipient address in the To field and send. (GitHub Pages sites cannot receive form posts on their own.)";
      }
    });
  });
})();
