#!/usr/bin/env python3
"""One-off generator for static HTML under docs/. Run: python3 docs/_build_static_pages.py"""

from pathlib import Path

ROOT = Path(__file__).resolve().parent


def shell(
    *,
    title: str,
    depth: int,
    nav: str,
    active: str,
    show_footer: bool,
    body_layout: str,
    main_class: str,
    inner_html: str,
    extra_scripts: str = "",
) -> str:
    p = "../" if depth == 1 else ""
    css = f"{p}static/css/styles.css"
    nav_js = f"{p}static/js/nav.js"
    footer_js = f"{p}static/js/footer.js" if show_footer else ""
    footer = (
        f'<div id="footer-root"></div>\n<script src="{footer_js}" defer></script>\n'
        if show_footer
        else ""
    )
    data_footer = ' data-show-footer="true"' if show_footer else ""
    if main_class == "main-app":
        inner_wrapped = (
            f'    <div class="main-app-inner stack-lg">\n{inner_html}\n    </div>'
        )
    else:
        inner_wrapped = inner_html
    depth_attr = str(depth)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title} – NeuroAssist</title>
  <link rel="stylesheet" href="{css}">
</head>
<body class="{body_layout}" data-nav="{nav}" data-nav-depth="{depth_attr}" data-active="{active}"{data_footer}>
  <a class="skip-link" href="#main-content">Skip to main content</a>
  <div id="nav-root"></div>
  <main id="main-content" class="{main_class}">
{inner_wrapped}
  </main>
{footer}  <script src="{nav_js}" defer></script>
{extra_scripts}</body>
</html>
"""


def write(rel: str, content: str) -> None:
    path = ROOT / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    print("wrote", rel)


# --- Marketing root (depth 0) ---
write(
    "index.html",
    shell(
        title="NeuroAssist",
        depth=0,
        nav="marketing",
        active="",
        show_footer=True,
        body_layout="layout-marketing",
        main_class="main-marketing",
        inner_html="""
    <section class="grid-hero">
      <div class="stack-md">
        <p class="pill"><span class="dot" aria-hidden="true"></span> Live captions for your laptop</p>
        <h1 class="hero-title">Turn every voice around you into clear, readable captions.</h1>
        <p class="muted" style="max-width:36rem;font-size:1rem;line-height:1.625">
          NeuroAssist listens through your laptop microphone and renders speech as large, legible captions you can follow at your own pace. This site runs entirely in your browser from GitHub Pages—no install required.
        </p>
        <div style="display:flex;flex-wrap:wrap;gap:0.75rem">
          <a class="btn btn-primary btn-lg" href="app/captions.html">Start live captions</a>
          <a class="btn btn-outline btn-lg" href="features.html">View all features</a>
          <a class="btn btn-ghost btn-lg" href="documentation/getting-started.html">Read docs</a>
        </div>
        <p class="small muted">No paid keys required. Uses the Web Speech API. Best in Chrome on desktop.</p>
      </div>
      <article class="card" aria-label="Preview">
        <div class="card-header" style="background:var(--slate-50);border-bottom:1px solid var(--slate-200)">
          <h2 class="card-title">Live captions preview</h2>
        </div>
        <div class="card-body" style="background:var(--slate-50);font-size:0.8125rem">
          <div style="border-radius:0.375rem;background:#fff;padding:0.5rem 0.75rem;border:1px solid #a7f3d0;margin-bottom:0.75rem">
            <p style="font-weight:600;color:#065f46;margin:0">Speaker 1</p>
            <p class="muted" style="margin-top:0.25rem;color:#1e293b">“Welcome to NeuroAssist. Everything you say appears here in real time.”</p>
          </div>
          <div style="border-radius:0.375rem;background:#fff;padding:0.5rem 0.75rem;border:1px solid #bae6fd;margin-bottom:0.75rem">
            <p style="font-weight:600;color:#075985;margin:0">Speaker 2</p>
            <p class="muted" style="margin-top:0.25rem;color:#1e293b">“You can tune fonts, spacing, and colors so captions match how you best read.”</p>
          </div>
        </div>
      </article>
    </section>
    <section class="stack-md" style="padding-bottom:2.5rem">
      <h2 style="font-size:1.125rem;font-weight:600;margin:0;color:var(--slate-900)">Built for real everyday listening</h2>
      <div class="grid-2">
        <article class="card"><div class="card-header"><h3 class="card-title" style="font-weight:600">Live captions that keep up</h3></div>
        <div class="card-body small muted">Continuous, low-latency captions tuned for conversations, meetings, and lectures.</div></article>
        <article class="card"><div class="card-header"><h3 class="card-title" style="font-weight:600">Accessibility-first design</h3></div>
        <div class="card-body small muted">High contrast themes, adjustable font sizes, and keyboard-friendly controls everywhere.</div></article>
        <article class="card"><div class="card-header"><h3 class="card-title" style="font-weight:600">Own your transcripts</h3></div>
        <div class="card-body small muted">Save sessions in your browser (IndexedDB), browse history, and copy text on your terms.</div></article>
      </div>
    </section>""",
    ),
)

features_inner = """
    <div class="page-header">
      <div><h1>Features</h1>
      <p class="page-header-desc">Everything in NeuroAssist is designed around one goal: make spoken words easier to follow and remember.</p></div>
      <div class="page-header-actions"><a class="btn btn-outline btn-sm" href="app/captions.html">Try live captions</a></div>
    </div>
    <div class="grid-2">
      <article class="card"><div class="card-header"><h2 class="card-title" style="font-weight:600">Live captions</h2></div>
      <div class="card-body"><ul class="small muted list-disc" style="padding-left:1.25rem">
        <li>Continuous captioning tuned for conversations and meetings.</li>
        <li>High-contrast caption blocks that auto-scroll as you speak.</li>
        <li>Keyboard shortcuts for start, pause, and save.</li>
      </ul></div></article>
      <article class="card"><div class="card-header"><h2 class="card-title" style="font-weight:600">Transcript library</h2></div>
      <div class="card-body"><ul class="small muted list-disc" style="padding-left:1.25rem">
        <li>Save a session with one shortcut and revisit it any time.</li>
        <li>Stored only in your browser on this device.</li>
      </ul></div></article>
    </div>"""

simple_pages = {
    "pricing.html": (
        "Pricing",
        "pricing.html",
        """<div class="page-header"><div><h1>Pricing</h1><p class="page-header-desc">The public demo is free in the browser. A future Pro plan is planned.</p></div></div>
    <div class="grid-2" style="gap:1.5rem">
      <article class="card card-emerald"><div class="card-header"><h2 class="card-title" style="font-size:1rem;font-weight:600">Free (GitHub Pages)</h2></div>
      <div class="card-body small muted"><p>Open the site from your browser. No account or API keys.</p>
      <ul class="list-disc" style="padding-left:1.25rem"><li>Live captions</li><li>Local transcript history (this device)</li></ul>
      <a class="btn btn-primary btn-sm" href="documentation/getting-started.html">How to use</a></div></article>
      <article class="card"><div class="card-header"><h2 class="card-title" style="font-size:1rem;font-weight:600">Pro (later)</h2></div>
      <div class="card-body small muted"><p>Future options for sync, themes, and translation APIs.</p></div></article>
    </div>""",
    ),
    "about.html": (
        "About",
        "about.html",
        """<div class="page-header"><div><h1>About NeuroAssist</h1><p class="page-header-desc">A tool for people who prefer reading to listening, and for anyone who benefits from visual support during conversations.</p></div></div>
    <article class="card"><div class="card-body" style="font-size:0.875rem;color:var(--slate-700)">
    <p>The goal of NeuroAssist is simple: make spoken language more comfortable to follow.</p>
    <p class="small muted">This version is a static site you can host on GitHub Pages; captions and transcripts stay in your browser.</p></div></article>""",
    ),
    "accessibility.html": (
        "Accessibility",
        "accessibility.html",
        """<div class="page-header"><div><h1>Accessibility at NeuroAssist</h1><p class="page-header-desc">Built for people who rely on captions and keyboard navigation.</p></div></div>
    <article class="card"><div class="card-body" style="font-size:0.875rem;color:var(--slate-700)">
    <p>High contrast text, visible focus, and layouts that adapt to different screens.</p></div></article>""",
    ),
    "privacy.html": (
        "Privacy",
        "privacy.html",
        """<div class="page-header"><div><h1>Privacy</h1><p class="page-header-desc">This demo runs in your browser; transcripts are stored locally on your device.</p></div></div>
    <article class="card"><div class="card-body" style="font-size:0.875rem;color:var(--slate-700)">
    <p>When you use the GitHub Pages site, audio is processed by your browser’s Web Speech API. Saved sessions use IndexedDB in your browser—not a NeuroAssist server.</p></div></article>""",
    ),
    "security.html": (
        "Security",
        "security.html",
        """<div class="page-header"><div><h1>Security</h1><p class="page-header-desc">No hosted backend in the static demo; your data stays on your device.</p></div></div>
    <article class="card"><div class="card-body" style="font-size:0.875rem;color:var(--slate-700)">
    <p>If you fork this project and add a server, add authentication and encryption as needed.</p></div></article>""",
    ),
}

for fname, (tit, act, inner) in simple_pages.items():
    write(
        fname,
        shell(
            title=tit,
            depth=0,
            nav="marketing",
            active=act,
            show_footer=True,
            body_layout="layout-marketing",
            main_class="main-marketing",
            inner_html=inner,
        ),
    )

write(
    "features.html",
    shell(
        title="Features",
        depth=0,
        nav="marketing",
        active="features.html",
        show_footer=True,
        body_layout="layout-marketing",
        main_class="main-marketing",
        inner_html=features_inner,
    ),
)

contact_extra = '  <script src="static/js/contact.js" defer></script>\n'
write(
    "contact.html",
    shell(
        title="Contact",
        depth=0,
        nav="marketing",
        active="contact.html",
        show_footer=True,
        body_layout="layout-marketing",
        main_class="main-marketing",
        inner_html="""
    <div class="page-header"><div><h1>Contact</h1><p class="page-header-desc">Send a message using your own email app.</p></div></div>
    <article class="card"><div class="card-body">
      <form id="contact-form" class="stack-md" style="gap:1rem">
        <div><label class="form-label" for="name">Name</label><input class="input" id="name" name="fromName" required autocomplete="name"></div>
        <div><label class="form-label" for="email">Email</label><input class="input" id="email" name="email" type="email" required autocomplete="email"></div>
        <div><label class="form-label" for="message">Message</label><textarea class="textarea" id="message" name="message" required></textarea></div>
        <div style="display:flex;flex-wrap:wrap;gap:0.75rem;align-items:center">
          <button class="btn btn-primary btn-sm" type="submit">Open in email app</button>
          <p class="small muted" id="contact-status" aria-live="polite"></p>
        </div>
      </form>
    </div></article>""",
        extra_scripts=contact_extra,
    ),
)

# Documentation (depth 1)
doc_shell = lambda title, active, inner: shell(
    title=title,
    depth=1,
    nav="marketing",
    active=active,
    show_footer=False,
    body_layout="layout-marketing",
    main_class="main-docs",
    inner_html=inner,
)

write(
    "documentation/index.html",
    doc_shell(
        "Documentation",
        "doc",
        """
    <div class="stack-md" style="gap:1.5rem">
      <header class="stack-md" style="gap:0.5rem">
        <p class="small" style="font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:var(--sky-700)">NeuroAssist Docs</p>
        <h1 style="font-size:1.5rem;font-weight:600;margin:0">Documentation</h1>
        <p class="small muted" style="max-width:42rem">Use NeuroAssist from GitHub Pages in your browser—no terminal required.</p>
      </header>
      <nav class="docs-grid" aria-label="Documentation sections">
        <a class="docs-link-card" href="getting-started.html"><p style="font-weight:500;margin:0">Getting started</p>
        <p class="small muted" style="margin-top:0.25rem">Enable GitHub Pages and use the site from any browser.</p></a>
        <a class="docs-link-card" href="how-captions.html"><p style="font-weight:500;margin:0">How live captions work</p>
        <p class="small muted" style="margin-top:0.25rem">Web Speech API and saving sessions in IndexedDB.</p></a>
        <a class="docs-link-card" href="translation.html"><p style="font-weight:500;margin:0">Translation</p>
        <p class="small muted" style="margin-top:0.25rem">Captions-focused mode on the static site.</p></a>
        <a class="docs-link-card" href="shortcuts.html"><p style="font-weight:500;margin:0">Keyboard shortcuts</p></a>
        <a class="docs-link-card" href="troubleshooting.html"><p style="font-weight:500;margin:0">Troubleshooting</p></a>
        <a class="docs-link-card" href="changelog.html"><p style="font-weight:500;margin:0">Changelog</p></a>
      </nav>
    </div>""",
    ),
)

write(
    "documentation/getting-started.html",
    doc_shell(
        "Getting started",
        "doc",
        """
    <div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">Getting started (GitHub Pages)</h1>
      <ol class="list-decimal">
        <li>In your GitHub repository, go to <strong>Settings → Pages</strong>.</li>
        <li>Under <strong>Build and deployment</strong>, set <strong>Source</strong> to <strong>Deploy from a branch</strong>.</li>
        <li>Choose branch <code class="code-inline">main</code> (or your default branch) and folder <code class="code-inline">/docs</code>, then save.</li>
        <li>After a minute, open the published URL (shown at the top of the Pages settings), e.g. <code class="code-inline">https://&lt;user&gt;.github.io/&lt;repo&gt;/</code>.</li>
        <li>Open <strong>Open app → Live Captions</strong>, allow the microphone, and start speaking.</li>
      </ol>
      <p class="muted">Transcripts are saved in <strong>IndexedDB</strong> in your browser (per site URL). They are not uploaded to GitHub.</p>
    </div>""",
    ),
)

write(
    "documentation/how-captions.html",
    doc_shell(
        "How live captions work",
        "doc",
        """<div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">How live captions work</h1>
      <p>NeuroAssist uses the Web Speech API. When you start listening, the browser converts microphone audio into text. Saving a session writes segments to <strong>IndexedDB</strong> in your browser (no server required on GitHub Pages).</p>
    </div>""",
    ),
)

write(
    "documentation/translation.html",
    doc_shell(
        "Translation",
        "doc",
        """<div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">Captions mode</h1>
      <p>This static build focuses on captions in one language via the Web Speech API.</p>
    </div>""",
    ),
)

write(
    "documentation/shortcuts.html",
    doc_shell(
        "Keyboard shortcuts",
        "doc",
        """<div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">Keyboard shortcuts</h1>
      <ul class="stack-md" style="list-style:none;padding:0">
        <li><span class="kbd">Space</span> – Start or pause on Live Captions.</li>
        <li><span class="kbd">Ctrl / Cmd + S</span> – Save session to IndexedDB.</li>
        <li><span class="kbd">Esc</span> – Stop listening.</li>
      </ul>
    </div>""",
    ),
)

write(
    "documentation/troubleshooting.html",
    doc_shell(
        "Troubleshooting",
        "doc",
        """<div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">Troubleshooting</h1>
      <ul class="list-disc stack-md" style="padding-left:1.25rem">
        <li><strong>No captions</strong>: Allow microphone access; try Chrome on desktop.</li>
        <li><strong>Unsupported browser</strong>: Use Chrome for best Web Speech support.</li>
        <li><strong>Save fails</strong>: Private mode or strict settings may block IndexedDB—try a normal window.</li>
      </ul>
    </div>""",
    ),
)

write(
    "documentation/changelog.html",
    doc_shell(
        "Changelog",
        "doc",
        """<div class="stack-md small" style="color:var(--slate-800);max-width:48rem">
      <h1 style="font-size:1.25rem;font-weight:600;margin:0">Changelog</h1>
      <ul class="list-disc" style="padding-left:1.25rem;color:var(--slate-700)">
        <li>Added static GitHub Pages site under <code class="code-inline">docs/</code> with IndexedDB transcripts.</li>
      </ul>
    </div>""",
    ),
)

# App pages (depth 1)
app_shell = lambda title, active, inner, scripts="": shell(
    title=title,
    depth=1,
    nav="app",
    active=active,
    show_footer=False,
    body_layout="layout-app",
    main_class="main-app",
    inner_html=inner,
    extra_scripts=scripts,
)

captions_inner = """
    <div class="page-header">
      <div><h1>Live Captions</h1><p class="page-header-desc">Space to start/pause, Ctrl/Cmd+S to save to this browser.</p></div>
      <div class="page-header-actions">
        <button type="button" class="btn btn-primary" id="btn-toggle-listen" aria-pressed="false">Start listening (Space)</button>
        <button type="button" class="btn btn-outline" id="btn-clear" disabled>Clear</button>
        <button type="button" class="btn btn-secondary" id="btn-save" disabled>Save session (Ctrl/Cmd+S)</button>
        <button type="button" class="btn btn-outline" id="btn-copy" disabled>Copy text</button>
      </div>
    </div>
    <div class="grid-captions">
      <section class="captions-panel">
        <div class="captions-panel-head">
          <h2 class="card-title">Live captions stream</h2>
          <span class="small muted">Status: <span id="caption-status" class="small" style="color:var(--slate-900);font-weight:500">Stopped</span></span>
        </div>
        <div style="padding:0 1rem">
          <p id="banner-unsupported" class="alert alert-amber" style="display:none;margin-bottom:0.75rem"></p>
          <p id="banner-error" class="alert alert-red" style="display:none;margin-bottom:0.75rem"></p>
        </div>
        <div id="captions-stream" class="captions-scroll" aria-label="Live captions">
          <p class="small muted">Press <strong>Space</strong> or <strong>Start listening</strong>.</p>
        </div>
      </section>
      <article class="card">
        <div class="card-header" style="padding-bottom:1rem"><h2 class="card-title" style="font-size:1rem;font-weight:600">Session settings</h2></div>
        <div class="card-body stack-md small muted" style="padding-top:1.5rem">
          <div><label class="form-label" for="caption-language">Language</label>
          <select class="select" id="caption-language" aria-label="Caption language">
            <option value="en-US">English (US)</option><option value="en-GB">English (UK)</option>
            <option value="es-ES">Spanish</option><option value="fr-FR">French</option>
          </select></div>
          <div style="display:flex;justify-content:space-between;border-top:1px solid var(--slate-100);padding-top:1rem">
            <span style="font-weight:500">Total segments</span><span id="segment-count" style="font-size:1.125rem;font-weight:700">0</span></div>
          <div style="display:none;justify-content:space-between" id="session-length-row">
            <span class="small">Session length</span><span id="session-length" class="small" style="font-weight:600"></span></div>
          <p id="save-error" class="alert alert-red" style="display:none"></p>
          <div><p class="small" style="font-weight:500;color:var(--slate-900)">Current buffer</p>
          <div id="full-buffer" class="small" style="height:6rem;overflow:auto;border:1px solid var(--slate-200);background:var(--slate-50);padding:0.35rem 0.5rem"></div></div>
        </div>
      </article>
    </div>"""

captions_scripts = """  <script src="../static/js/storage.js"></script>
  <script src="../static/js/captions.js" defer></script>
"""

write(
    "app/index.html",
    app_shell(
        "Dashboard",
        "index.html",
        """
    <div class="page-header"><div><h1>Welcome to NeuroAssist</h1>
    <p class="page-header-desc">Start captions and review transcripts—all in your browser.</p></div></div>
    <div class="grid-dashboard">
      <article class="card"><div class="card-header"><h2 class="card-title" style="font-weight:600">Quick start</h2></div>
      <div class="card-body small muted"><ol class="list-decimal">
        <li>Open <a href="captions.html" style="font-weight:500">Live Captions</a>.</li>
        <li>Press Space to start or pause.</li>
        <li>Ctrl/Cmd+S saves to this browser (IndexedDB).</li>
      </ol></div></article>
      <article class="card" style="background:var(--slate-50)"><div class="card-header"><h2 class="card-title" style="font-size:0.875rem;font-weight:600">Device</h2></div>
      <div class="card-body small muted"><p>Use Chrome on desktop with a headset for best results.</p></div></article>
    </div>""",
    ),
)

write(
    "app/captions.html",
    app_shell("Live Captions", "captions.html", captions_inner, captions_scripts),
)

write(
    "app/transcripts.html",
    app_shell(
        "Transcripts",
        "transcripts.html",
        """
    <div class="page-header"><div><h1>Transcripts</h1><p class="page-header-desc">Saved on this device only (IndexedDB).</p></div></div>
    <article class="card"><div class="card-header"><h2 class="card-title">Saved sessions</h2></div>
    <div class="card-body small" style="color:var(--slate-700)">
      <p id="transcripts-error" class="alert alert-red" style="display:none"></p>
      <ul id="transcripts-list" class="stack-md" style="list-style:none;padding:0;margin:0"></ul>
    </div></article>""",
        """  <script src="../static/js/storage.js"></script>
  <script src="../static/js/transcripts-page.js" defer></script>
""",
    ),
)

write(
    "app/transcript.html",
    app_shell(
        "Transcript",
        "transcript.html",
        """<div id="transcript-detail-root"></div>""",
        """  <script src="../static/js/storage.js"></script>
  <script src="../static/js/transcript-detail.js" defer></script>
""",
    ),
)

settings_links = """
    <div class="page-header"><div><h1>Settings</h1><p class="page-header-desc">Placeholder sections for a full product.</p></div></div>
    <div class="grid-2">
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-audio.html" style="text-decoration:none;color:inherit">Audio</a></h2></div>
      <div class="card-body">Microphone options.</div></article>
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-display.html" style="text-decoration:none;color:inherit">Display</a></h2></div>
      <div class="card-body">Caption layout and appearance.</div></article>
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-accessibility.html" style="text-decoration:none;color:inherit">Accessibility</a></h2></div>
      <div class="card-body">Fonts and contrast.</div></article>
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-privacy.html" style="text-decoration:none;color:inherit">Privacy</a></h2></div>
      <div class="card-body">Data retention.</div></article>
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-shortcuts.html" style="text-decoration:none;color:inherit">Shortcuts</a></h2></div>
      <div class="card-body">Keyboard bindings.</div></article>
      <article class="card card-dark"><div class="card-header" style="border-color:rgba(51,65,85,0.5)"><h2 class="card-title" style="color:var(--slate-100)"><a href="settings-account.html" style="text-decoration:none;color:inherit">Account</a></h2></div>
      <div class="card-body">Local profile.</div></article>
    </div>"""

write(
    "app/settings.html",
    app_shell("Settings", "settings.html", settings_links),
)

for fname, tit, act, body in [
    (
        "settings-audio.html",
        "Audio settings",
        "settings-audio.html",
        "<article class=\"card card-dark\"><div class=\"card-body\">Placeholder: input devices and levels.</div></article>",
    ),
    (
        "settings-display.html",
        "Display",
        "settings-display.html",
        "<article class=\"card card-dark\"><div class=\"card-body\">Placeholder: font size and themes.</div></article>",
    ),
    (
        "settings-accessibility.html",
        "Accessibility",
        "settings-accessibility.html",
        "<article class=\"card card-dark\"><div class=\"card-body\">Placeholder: contrast and dyslexia-friendly options.</div></article>",
    ),
    (
        "settings-privacy.html",
        "Privacy",
        "settings-privacy.html",
        "<article class=\"card card-dark\"><div class=\"card-body\">Placeholder: retention and local-only mode.</div></article>",
    ),
    (
        "settings-shortcuts.html",
        "Shortcuts",
        "settings-shortcuts.html",
        "<article class=\"card card-dark\"><div class=\"card-body\"><p>Space, Ctrl/Cmd+S, Esc on Live Captions.</p></div></article>",
    ),
    (
        "settings-account.html",
        "Account",
        "settings-account.html",
        "<article class=\"card card-dark\"><div class=\"card-body\">Local-first profile on this device.</div></article>",
    ),
]:
    write(
        f"app/{fname}",
        app_shell(
            tit,
            act,
            f"""<div class="page-header"><div><h1>{tit}</h1></div></div>{body}""",
        ),
    )

write(
    "app/help.html",
    app_shell(
        "Help",
        "help.html",
        """<div class="page-header"><div><h1>Help &amp; FAQ</h1></div></div>
    <article class="card card-dark"><div class="card-body stack-md">
      <p>See <a class="underline" href="../documentation/getting-started.html">Getting started</a> and <a class="underline" href="../documentation/troubleshooting.html">Troubleshooting</a>.</p>
    </div></article>""",
    ),
)

write(
    "app/onboarding.html",
    app_shell(
        "Onboarding",
        "onboarding.html",
        """<div class="page-header"><div><h1>Onboarding</h1></div></div>
    <article class="card card-dark"><div class="card-body stack-md">
      <ol class="list-decimal"><li>Allow the microphone.</li><li>Open <a class="underline" href="captions.html">Live Captions</a>.</li><li>Save with Ctrl/Cmd+S.</li></ol>
      <a class="btn btn-primary btn-sm" href="captions.html">Start</a>
    </div></article>""",
    ),
)

print("done")
